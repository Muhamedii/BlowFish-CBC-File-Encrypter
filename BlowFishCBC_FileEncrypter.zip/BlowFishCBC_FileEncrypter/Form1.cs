using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using System.Text;

namespace BlowFishCBC_FileEncrypter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "All Files|*.*";
                openFileDialog.Title = "Select a file";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    txtFilePath.Text = openFileDialog.FileName;
                }
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            string filePath = txtFilePath.Text;
            string key = txtKey.Text;

            if (!string.IsNullOrEmpty(filePath) && !string.IsNullOrEmpty(key))
            {
                try
                {
                    byte[] keyBytes = Encoding.UTF8.GetBytes(key);
                    byte[] inputBytes = File.ReadAllBytes(filePath);

                    byte[] ivBytes = new byte[8]; // 8 bytes for Blowfish block size
                    SecureRandom random = new SecureRandom();
                    random.NextBytes(ivBytes);

                    // Make inputBytes size a multiple of the block size
                    int remainder = inputBytes.Length % 8;
                    if (remainder != 0)
                    {
                        byte[] paddedInputBytes = new byte[inputBytes.Length + (8 - remainder)];
                        Array.Copy(inputBytes, paddedInputBytes, inputBytes.Length);
                        inputBytes = paddedInputBytes;
                    }

                    CbcBlockCipher blockCipher = new CbcBlockCipher(new BlowfishEngine());
                    BufferedBlockCipher cipher = new BufferedBlockCipher(blockCipher);

                    KeyParameter keyParam = new KeyParameter(keyBytes);
                    ParametersWithIV keyParamWithIV = new ParametersWithIV(keyParam, ivBytes);

                    cipher.Init(true, keyParamWithIV);

                    byte[] outputBytes = new byte[cipher.GetOutputSize(inputBytes.Length)];
                    int length = cipher.ProcessBytes(inputBytes, 0, inputBytes.Length, outputBytes, 0);
                    length += cipher.DoFinal(outputBytes, length);

                    string encryptedFilePath = Path.Combine(Path.GetDirectoryName(filePath), "EncryptedFile.enc");
                    File.WriteAllBytes(encryptedFilePath, outputBytes);

                    // Inform the user about the location of the encrypted file using a dialog
                    MessageBox.Show($"File encrypted successfully! Encrypted file saved to:\n{encryptedFilePath}",
                                    "Encryption Success",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Encryption failed! " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter a file path and key!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}