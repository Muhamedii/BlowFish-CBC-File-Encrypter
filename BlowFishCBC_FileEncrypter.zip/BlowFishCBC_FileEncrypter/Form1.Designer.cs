﻿namespace BlowFishCBC_FileEncrypter
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblKey = new System.Windows.Forms.Label();
            this.lblFilePath = new System.Windows.Forms.Label();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.btnSelectFile = new System.Windows.Forms.Button();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblKey
            this.lblKey.AutoSize = true;
            this.lblKey.Location = new System.Drawing.Point(30, 30);
            this.lblKey.Size = new System.Drawing.Size(40, 15);
            this.lblKey.Text = "Key:";
            this.Controls.Add(this.lblKey);

            // lblFilePath
            this.lblFilePath.AutoSize = true;
            this.lblFilePath.Location = new System.Drawing.Point(30, 70);
            this.lblFilePath.Size = new System.Drawing.Size(75, 15);
            this.lblFilePath.Text = "File Path:";
            this.Controls.Add(this.lblFilePath);

            // txtKey
            this.txtKey.Location = new System.Drawing.Point(80, 27);
            this.txtKey.Size = new System.Drawing.Size(200, 25);
            this.Controls.Add(this.txtKey);

            // txtFilePath
            this.txtFilePath.Location = new System.Drawing.Point(110, 67);
            this.txtFilePath.Size = new System.Drawing.Size(150, 25);
            this.Controls.Add(this.txtFilePath);

            // btnSelectFile
            this.btnSelectFile.Location = new System.Drawing.Point(270, 67);
            this.btnSelectFile.Size = new System.Drawing.Size(100, 25);
            this.btnSelectFile.Text = "Select File";
            this.btnSelectFile.Click += new System.EventHandler(this.btnSelectFile_Click);
            this.Controls.Add(this.btnSelectFile);

            // btnEncrypt
            this.btnEncrypt.Location = new System.Drawing.Point(30, 110);
            this.btnEncrypt.Size = new System.Drawing.Size(120, 35);
            this.btnEncrypt.Text = "Encrypt";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            this.Controls.Add(this.btnEncrypt);

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblKey;
        private System.Windows.Forms.Label lblFilePath;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.Windows.Forms.Button btnSelectFile;
        private System.Windows.Forms.Button btnEncrypt;
    }
}